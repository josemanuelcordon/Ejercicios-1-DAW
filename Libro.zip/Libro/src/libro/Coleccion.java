
package libro;
import java.util.ArrayList; 

public class Coleccion extends Libro
{
    private ArrayList<Libro> coleccion;
    public Coleccion() 
    {
        ArrayList<Libro> coleccion = new ArrayList<Libro>();
        this.coleccion = coleccion;
    }
    
    public void añadir(Libro libro) 
    {
        coleccion.add(libro);
    
    }
    
    public int longitud()
    {
        int n_libros = coleccion.size();
        return n_libros;
    }
    
    public ArrayList<String> mismoAutor(String autor)
    {
        ArrayList<String> mismo_autor = new ArrayList<String>();
        
        for(int i = 0; i< coleccion.size(); i++)
        {
            String autor_libro = (coleccion.get(i)).getAutor();
            if (autor_libro.equals(autor))
            {
                mismo_autor.add((coleccion.get(i)).getTitulo());
            }
        }
        return mismo_autor;
    }
    

}
