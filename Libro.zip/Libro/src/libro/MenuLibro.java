
package libro;
import java.util.Scanner;
public class MenuLibro {

    public static void main(String args[]) {
        
        Libro libro1 = new Libro("12312314","El archivo de las Tormentas","Brandom Sanderson", 1230);
        Libro libro2 = new Libro("125847A", "El Quijote", "Miguel de Cervantes", 608);
        Libro libro3 = new Libro("56920A", "La isla del Tesoro", "Robert Louis Stevenson" , 317);
        Libro libro4 = new Libro("125847A", "El Quijote", "Miguel de Cervantes", 608);
        int opcion = 0;
        do {         //mostrar menu de inicio
        Scanner lectura = new Scanner(System.in);
        System.out.println("ESTE ES EL SISTEMA DE LA BIBLIOTECA DE DAW:");
        System.out.println("0 -> Mostrar libros disponibles");
        System.out.println("1 -> Mostrar libro 1");
        System.out.println("2 -> Mostrar libro 2");
        System.out.println("3 -> Mostrar libro 3");
        System.out.println("4 -> Mostrar libro 4");
        System.out.println("5 -> Libros con el mismo autor");
        System.out.println("6 -> Salir del Sistema");
        Libro[] lista_libros = {libro1, libro2, libro3,libro4};
        Coleccion biblioteca = new Coleccion();
        for(int i = 0; i < lista_libros.length; i++)
        {
            biblioteca.añadir(lista_libros[i]);
        }
        System.out.println("Que desea hacer: ");
        try 
        {
            opcion = lectura.nextInt();
        } 
        catch(Exception e)
        {
            System.out.println("Introduce un dato valido");
        }
        switch(opcion)
        {
            case 0:
                for(int i = 0; i < lista_libros.length; i++)
                {
                    System.out.println("----------------------------------------");
                    System.out.println("Libro nº " + (i+1));
                    lista_libros[i].mostrarLibro();
                }
                System.out.println("----------------------------------------");
                break;
            case 1:
                System.out.println("El autor del libro nº 1 es: " + lista_libros[opcion-1].getAutor() );
                break;
            case 2:
                System.out.println("El autor del libro nº 2 es: " + lista_libros[opcion-1].getAutor() );
                break;
            case 3:
                System.out.println("El autor del libro nº 3 es: " + lista_libros[opcion-1].getAutor() );
                break;
            case 4:
                System.out.println("El autor del libro nº 4 es: " + lista_libros[opcion-1].getAutor() );
                break;
            
            case 5 :
                Scanner lectura2 = new Scanner(System.in);
                System.out.println("Que autor quieres buscar:");
                String autor = lectura2.nextLine();
                System.out.println(biblioteca.mismoAutor(autor));
            case 6:
                
                        
                System.out.println("Gracias por usar nuestro servicio! :)");
                break;
        }
        
        }while(opcion != 5);
                 
                
        
        
        
     
        
     

        
        
    }
}
