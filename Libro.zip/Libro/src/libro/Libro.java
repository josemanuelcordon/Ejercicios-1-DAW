
package libro;

public class Libro {
    private String isbn;
    private String titulo;
    private String autor;
    private int numPags;
   
    public Libro () {
    }
    
    
    public Libro(String isbn, String titulo, String autor, int numPags) {
        this.isbn = isbn;
        this.autor = autor;
        this.titulo = titulo;
        this.numPags = numPags;
        
        
    }
    
    public String getTitulo () 
    {
        return titulo;
    }
    public String getAutor ()
    {
        return this.autor;
    }
    public int getNumPags () 
    {
        return numPags;
    }
    public void setTitulo(String nuevoTitulo) 
    {
    this.titulo = nuevoTitulo;
    }
    
    public void mostrarLibro () {
        
        System.out.println("Titulo: " + this.titulo);
        
    }
    public void compararPaginas(Libro libro1)
    {
        if (libro1.numPags > this.numPags)
        {
            System.out.println(libro1.titulo + " tiene más paginas que " + this.titulo);
        }
        else 
        {
            if(libro1.numPags < this.numPags)
            {
                   System.out.println(this.titulo + " tiene más paginas que " + libro1.titulo);
            }
            else 
            {
                System.out.println(this.titulo + " tiene las mismas páginas que " + libro1.titulo);
            }
        }
    }
}


