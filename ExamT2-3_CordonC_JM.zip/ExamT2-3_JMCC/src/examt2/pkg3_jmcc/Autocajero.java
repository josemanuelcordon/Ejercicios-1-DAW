// Cordón Castillo, José Manuel
package examt2.pkg3_jmcc;
import bpc.daw.objetos.TarjetaCredito;
import java.util.Scanner;

public class Autocajero {

    
    public static void main(String args[]) {
        TarjetaCredito tarjeta = new TarjetaCredito(100, 91222);
        Scanner lectura = new Scanner(System.in);
        int password = 0;
        int intentos = 3;
        boolean  salir = false;
        char opcion;
        int importe;
        
        while ((password != 91222) && (intentos > 0))  // aquí vamos comprobando si la contraseña es correcta y si hemos superado el numero de intentos permitidos
        {
            System.out.println("Introduzca la clave:");
            password = lectura.nextInt();
            System.out.println("Has marcado la contraseña: " + password);
            if (intentos == 0) 
            {
                System.out.println("Ha agotado todos sus intentos");
            }
            else 
            {
                if (password != 91222)
                {
                    
                    System.out.println("No es la contraseña correcta, vuelva a intentarlo");
                    System.out.println("Le quedan " + (intentos - 1) + " intentos");
                    intentos--;
                }
                else // en caso de que la contraseña sea correcta y el numero de intentos no haya superado los tres mostramos el menú
                {
                    try // para casi todos los métodos tenemos que gestionar la excepcion java.lang.Exception que se produce cuando la contraseña es incorrecta
                    {   // esto es necesario, aunque ya nos habíamos asegurado en el bucle while y con los if que la contraseña era correcta, y no la vamos a volver a introducir.
                        System.out.println("Contraseña aceptada con saldo inicial: " + tarjeta.getSaldo(password));
                    }
                    catch (Exception e)
                    {
                        System.out.println("Contraseña incorrecta");
                    }
                    do 
                    {
                        System.out.println("Indique la operacion a realizar: Ingresar(I),"
                                + " Retirar(R), Terminar(T), Saldo actual(S)");
                        opcion = lectura.next().charAt(0);
                        switch (opcion)
                        {
                            case ('I'):
                                System.out.println("Indique el importe con el que desea operar:");
                                importe = lectura.nextInt(); //comprobamos que el importe sea positivo, si es negativo informamos y volvemos a mostrar el menú
                                if (importe <= 0)            // para este método no utilizamos la contraseña por tanto no hay que gestionar ninguna excepcion.
                                {
                                    System.out.println("Introduzca una cantidad positiva");
                                }
                                else 
                                {
                                    tarjeta.ingresarDinero(importe);
                                    System.out.println("Se han ingresado " + importe + " euros");
                                }
                                break;
                            case ('i'):
                                System.out.println("Indique el importe con el que desea operar:");
                                importe = lectura.nextInt();
                                if (importe <= 0)
                                {
                                    System.out.println("Introduzca una cantidad positiva");
                                }
                                else 
                                {
                                    tarjeta.ingresarDinero(importe);
                                    System.out.println("Se han ingresado " + importe + " euros");
                                }
                                break;
                            case ('R'):
                                System.out.println("Indique el importe con el que desea operar:");
                                importe = lectura.nextInt();
                                if (importe <= 0) // de igual forma que al ingresar, pero aquí hay que gestionar, con el try-catch la contraseña incorrecta (que nunca lo va a ser)
                                {                 // y con el if gestionamos si hay suficiente cantidad en la cuenta para retirar ese importe, ya que devuelve false si no hay suficiente dinero.  
                                    System.out.println("Introduzca un importe positivo");
                                }
                                else
                                {
                                    try 
                                    {
                                        if (tarjeta.sacarDinero(importe, password))
                                        {
                                            System.out.println("Se han retirado " + importe + " euros" );
                                        }
                                        else
                                        {
                                            System.out.println("No se puede retirar tal cantidad");
                                        }
                                    }
                                    catch (java.lang.Exception e)
                                    {
                                        System.out.println("La password es incorrecta");
                                    }
                                }
                                break;
                            case ('r'):
                                System.out.println("Indique el importe con el que desea operar:");
                                importe = lectura.nextInt();
                                if (importe <= 0)
                                {
                                    System.out.println("Introduzca un importe positivo");
                                }
                                else
                                {
                                    try 
                                    {
                                        if (tarjeta.sacarDinero(importe, password))
                                        {
                                            System.out.println("Se han retirado " + importe + " euros" );
                                        }
                                        else
                                        {
                                            System.out.println("No se puede retirar tal cantidad");
                                        }
                                    }
                                    catch (java.lang.Exception e)
                                    {
                                        System.out.println("La password es incorrecta");
                                    }
                                }
                                break;
                            case ('S'): // al igual que en el resto de métodos que introducimos la contraseña, tenemos que gestionar la excepcion, aunque al principìo del programa 
                                try     // ya nos habíamos asegurado de ello.
                                {
                                    System.out.println("Saldo actual de su tarjeta: " + tarjeta.getSaldo(password));
                                }
                                catch (java.lang.Exception a)
                                {
                                    System.out.println("La password es incorrecta");
                                }
                                break;
                            case ('s'):
                                try 
                                {
                                    System.out.println("Saldo actual de su tarjeta: " + tarjeta.getSaldo(password));
                                }
                                catch (java.lang.Exception a)
                                {
                                    System.out.println("La password es incorrecta");
                                }
                                break;
                            case ('T'):
                                salir = true;   // cambiamos la variable de control del menú a true para salirnos.
                                System.out.println("Ha pulsado terminar de operar en Cajero");
                                System.out.println("Gracias por confiar en nosotros");
                                System.out.println("Retire su tarjeta");
                                break;
                            case ('t'):
                                salir = true;
                                System.out.println("Ha pulsado terminar de operar en Cajero");
                                System.out.println("Gracias por confiar en nosotros");
                                System.out.println("Retire su tarjeta");
                                break;
                            default:
                                System.out.println("Introduzca una opcion valida"); // aquí gestionamos que el usuario introduzca una opcion no valida.
                                break;
                        }
                    }
                    while (!salir); // cuando salir tiene el valor true, salimos del menú.
                }
            }
        }
        
        
        
        
    }
}
