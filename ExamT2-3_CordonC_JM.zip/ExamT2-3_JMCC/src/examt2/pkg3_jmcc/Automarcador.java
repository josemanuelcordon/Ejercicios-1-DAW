// Cordón Castillo, José Manuel
package examt2.pkg3_jmcc;
import bpc.daw.objetos.MarcadorBaloncesto;
import java.util.Scanner;

public class Automarcador {

    
    public static void main(String[] args) {
        Scanner lectura = new Scanner(System.in);
        String equipo_local = "Estudiantes";
        String equipo_visitante = "CB Granada";
        MarcadorBaloncesto marcador = new MarcadorBaloncesto(equipo_local, equipo_visitante);
        System.out.println("Marcador automatico entre equipos, local: " + equipo_local + ";" 
                + " visitante: " + equipo_visitante + ".");
        System.out.println("Pulse la tecla 'P' para visualizar el marcador actual");
        System.out.println("Pulse la tecla 'S' para visualizar el marcador final"
                + " y terminar el partido");
        System.out.println("Marque la canasta de la forma:");
        System.out.println("1) Indique equipo anotador: pulse letra L (local) o "
                + "V (visitante) + INTRO");
        System.out.println("2) Marque la puntuacion anotada por dicho equipo: "
                + "(entero 1,2 o 3) + INTRO");
        char opcion = 'a';
        int puntos = 0;
        boolean salir = false;
        do  //Una vez indicado las instrucciones del menú, comenzamos a imprimirlo utilizando este bucle 
            //y teniendo una variable booleana de control para saber cuando el usuario desea abandonar nuestro menú 
        {
            System.out.println("Indique equipo anotador (L|V), S (salir), P (puntos actuales)");
            opcion = lectura.next().charAt(0);
            switch(opcion)
            {
                case ('L'):
                    System.out.println("Indique la puntuacion de la canasta:");
                    puntos = lectura.nextInt();
                    if (marcador.anotarCanasta('L', puntos))   // como el método devuelve false si le introducimos una puntuacion no valida
                    {                                                // empleamos un if para controlar si la puntuacion introducida es correcta o no.               
                        System.out.println("Marca local con canasta de " + puntos + " puntos");
                    }
                    else
                    {
                        System.out.println("Introduzca una puntuacion valida de canasta");
                    }
                    break;
                case ('l'):
                    System.out.println("Indique la puntuacion de la canasta:");
                    puntos = lectura.nextInt();
                    if (marcador.anotarCanasta('L', puntos))
                    {
                        System.out.println("Marca local con canasta de " + puntos + " puntos");
                    }
                    else
                    {
                        System.out.println("Introduzca una puntuacion valida de canasta");
                    }
                    break;
                case ('V'):
                    System.out.println("Indique la puntuacion de la canasta:");
                    puntos = lectura.nextInt();
                    if (marcador.anotarCanasta('V', puntos))
                    {    
                        System.out.println("Marca visitante con canasta de " + puntos + " puntos");
                    }
                    else 
                    {
                        System.out.println("Introduzca una puntuacion valida de canasta");
                    }
                    break;
                case ('v'):
                    System.out.println("Indique la puntuacion de la canasta:");
                    puntos = lectura.nextInt();
                    if (marcador.anotarCanasta('V', puntos))
                    {    
                        System.out.println("Marca visitante con canasta de " + puntos + " puntos");
                    }
                    else 
                    {
                        System.out.println("Introduzca una puntuacion valida de canasta");
                    }
                    break;
                case ('P'):
                    System.out.println("En estos momentos");
                    System.out.println(marcador.toString());         // con el método toString() nos ahorramos un par de lineas de codigo ya que 
                    break;                                             // nos muestra el marcador
                case ('p'):
                    System.out.println("En estos momentos");
                    System.out.println(marcador.toString());
                    break;
                case ('S'):
                    System.out.println("Ha pulsado salir del marcador");
                    System.out.println("Fin de partido, marcador final:");
                    System.out.println(marcador.toString());
                    salir = true;
                    break;
                case ('s'):
                    System.out.println("Ha pulsado salir del marcador");
                    System.out.println("Fin de partido, marcador final:");
                    System.out.println(marcador.toString());
                    salir = true;
                    break;
                default:
                    System.out.println("Introduzca una opcion válida");   // en el caso default colocamos la posibilidad 
                    break;                                                  // de que la opcion introducida por el usuario no sea correcta.
            }   
        }
        while (!salir); //si pulsamos las teclas s o S, la variable de control cambia a true y salimos del menú.
    }
    
}
