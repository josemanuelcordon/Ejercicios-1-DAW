
package mario_lib;
import java.util.Scanner;
public class Ejercicio16 {

    
    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca el texto 1");
        String texto1 = lectura.nextLine();
        System.out.println("Introduzca el texto 2");
        String texto2 = lectura.nextLine();
        System.out.println(texto1.contains(texto2));
    }
}
