package mario_lib;
import java.util.Scanner;
import java.io.File;

public class Ejercicio21 {

   
    public static void main(String args[]) 
    {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduce la ruta de un directorio");
        String path = lectura.nextLine();
        File directorio = new File(path);
        if (directorio.isDirectory())
        {
            String[] ficheros_directorios = directorio.list();
            System.out.println("Los ficheros y directorios de la ruta especificada son:");
            for (int i = 0; i < ficheros_directorios.length ; i++)
            {
                System.out.println(" / " + ficheros_directorios[i] + " / ");
            }
        }
        
    }
}
