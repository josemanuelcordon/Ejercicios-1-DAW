/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package mario_lib;
import java.io.File;
import java.util.Scanner;

public class Ejercicio19 {

    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduce la dirección del archivo:");
        String path = lectura.nextLine();
        File fichero = new File(path);
        long tamaño = fichero.length();
        System.out.println(tamaño);
        
    }
}
