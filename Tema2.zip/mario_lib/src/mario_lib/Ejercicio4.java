
package mario_lib;
import bpc.daw.mario.*;
public class Ejercicio4 {

    
    public static void main(String args[]) 
    {
        Luigi luigi1 = new Luigi(500);
        Mario mario1 = new Mario(luigi1,40);
        int coodernadaX_mario1 = mario1.getX();
        int coordenadaY_mario1 = mario1.getY();
        int coordenadaX_luigi1 = luigi1.getX();
        int coordenadaY_luigi1 = luigi1.getY();
        System.out.println("Las coordenadas (x,y) de mario son: (" + coodernadaX_mario1 + "," + coordenadaY_mario1 + ")");
        System.out.println("Las coordenadas (x,y) de mario son: (" + coordenadaX_luigi1 + "," + coordenadaY_luigi1 + ")");
    }
}
