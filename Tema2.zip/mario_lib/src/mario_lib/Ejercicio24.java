
package mario_lib;
import java.io.PrintWriter;
import java.io.File;
import java.util.Scanner;

public class Ejercicio24 {

    
    public static void main(String args[]) {
        try 
        {
            Scanner lectura = new Scanner(System.in);
            System.out.println("Introduce dos frases para imprimir en el fichero prueba:");
            String frase1 = lectura.nextLine();
            String frase2 = lectura.nextLine();
            PrintWriter fichero_escribir = new PrintWriter("/home/jose/Documentos/prueba.txt");
            fichero_escribir.println(frase1);
            fichero_escribir.println(frase2);
            fichero_escribir.close();
        }
        catch(java.io.IOException error1)
        {
            System.out.println("No se puede crear el fichero");
        }
        
    }
}
