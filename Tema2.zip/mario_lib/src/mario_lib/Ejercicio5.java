
package mario_lib;
import bpc.daw.mario.*;
public class Ejercicio5 {

    
    public static void main(String args[]) 
    {
        Cañon cañon1 = new Cañon(0,540);
        Cañon cañon2 = new Cañon(1920,540);
        cañon1.disparar(1920,540);
        cañon1.disparar(1920,0);
        cañon1.disparar(1920,1080);
        cañon2.disparar(0,0);
        cañon2.disparar(0,1080);
        int numero_disparos_cañon1 = cañon1.getTotalDisparosRealizados();
        int numero_disparos_cañon2 = cañon2.getTotalDisparosRealizados();
        System.out.println("El numero de disparos del cañon 1 es: " + numero_disparos_cañon1);
        System.out.println("El numero de disparos del cañon 2 es: " + numero_disparos_cañon2);
        
    }
}
