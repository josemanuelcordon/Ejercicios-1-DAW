
package mario_lib;
import java.util.Scanner;

public class Ejercicio17 {

    
    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Cual es tu nombre:");
        String nombre = lectura.nextLine();
        System.out.println("Cual es tu dominio:");
        String dominio = lectura.nextLine();
        if ((dominio.endsWith(".es")) || (dominio.endsWith(".com")))
        {
            String correo = nombre + "@" + dominio;
            System.out.println(correo);
        }
        else
        {
            System.out.println("El dominio no es correcto, introduzcalo de nuevo");
        }
    }
}
