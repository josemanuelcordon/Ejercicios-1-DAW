package mario_lib;

import java.io.File;
import java.util.Scanner;

public class Ejercicio20 {

    
    public static void main(String args[]) 
    {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca la ruta del archivo:");
        String path = lectura.nextLine();
        File fichero = new File(path);
        if ((fichero.exists()) && (fichero.isDirectory()))
        {
            long tamaño_directorio = fichero.length();
            System.out.println("La ruta introducida es un archivo de tamaño " + tamaño_directorio + " bytes");
            System.out.println("Desea borrarlo (s/n)");
            char comprobacion = lectura.next().charAt(0);
            if (comprobacion == 's' || comprobacion == 'S') 
            {
                fichero.delete();
            }
            else
            {
                System.out.println("Borrado cancelado");
            }
            
                   
        }
        else
        {
            System.out.println("O la ruta esta mal, o no es un directorio");
            
        }
        
    }
}
