package mario_lib;
import java.util.Scanner;
import java.io.File;

public class Ejercicio25 {

    
    public static void main(String args[]) 
    {
        try 
        {
        File fichero = new File("/home/jose/Documentos/prueba.txt");
        Scanner leer_fichero = new Scanner(fichero);
        while (leer_fichero.hasNextLine())
        {
            System.out.println(leer_fichero.nextLine());
        }
        
        }
        catch(java.io.FileNotFoundException error1)
        {
            System.out.println("El fichero no existe");
        }
    }
}
