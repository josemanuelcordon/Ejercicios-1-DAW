package mario_lib;
import java.net.InetAddress;
import java.util.Scanner;

public class Ejercicio27 {

    
    public static void main(String args[]) {
        try 
        {
            Scanner lectura = new Scanner(System.in);
            System.out.println("Introduzca una dirección IP");
            String ip = lectura.nextLine();
            System.out.println("Introduzca un timeout");
            int timeout = lectura.nextInt();
            InetAddress ordenador = InetAddress.getByName(ip);
            if (ordenador.isReachable(timeout))
            {
                System.out.println("Le ha llegado el ping");
                        
            }
            else 
            {
                System.out.println("No hemos obtenido respuesta");
            }
        }
        catch(java.net.UnknownHostException error1)
        {
            System.out.println("No se pudo obtener la dirección IP");
        }
        catch(java.io.IOException error2)
        {
            System.out.println("No");
        }
        
        
    }
}
