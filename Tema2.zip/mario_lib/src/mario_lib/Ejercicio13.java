/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package mario_lib;

import java.util.Scanner;
public class Ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca su nombre:");
        String nombre = lectura.nextLine();
        String nombre_mayuscula = nombre.toUpperCase();
        String nombre_minuscula = nombre.toLowerCase();
        int caracteres = nombre.length();
        System.out.println("Su nombre en mayusculas es: " +nombre_mayuscula);
        System.out.println("Su nombre en minusculas es: " +nombre_minuscula);
        System.out.println("Total de caracteres del nombre: " +caracteres);
        
    }
}
