

package mario_lib;
import bpc.daw.mario.*;
public class Foto_Real_Madrid 
{
    public static void main(String[] args) 
    {
       Mario mario = new Mario(860, 540);
       Luigi luigi = new Luigi(900, 540);
       Seta seta = new Seta(940,540);
       Planta planta = new Planta(980,540);
       Cañon cañon = new Cañon(1020,540);
       Disparo disparo = new Disparo(1070,540,810,540);
    }
    

   
    
}
