/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package mario_lib;

import bpc.daw.objetos.*;
public class Ejercicio11 {

    public static void main(String args[]) {
       Caja caja1 = new Caja("Caja1");
       caja1.abrirCaja();
       Caja caja2 = new Caja("Caja2");
       caja2.abrirCaja();
       String mensaje_caja1 = caja1.getMensaje();
       String mensaje_caja2 = caja2.getMensaje();
       caja1.cambiarMensaje(mensaje_caja2);
       caja2.cambiarMensaje(mensaje_caja1);
       
    }
}
