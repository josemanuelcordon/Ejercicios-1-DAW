
package mario_lib;
import bpc.daw.objetos.TarjetaCredito;

public class Ejercicio22 
{

    
    public static void main(String args[]) 
    {   
        try 
        {
        TarjetaCredito mi_tarjeta = new TarjetaCredito(5000,1111);
        System.out.println("El saldo de la cuenta es: " + mi_tarjeta.getSaldo(1111));
        mi_tarjeta.sacarDinero(2000,1111);
        System.out.println("Despues de la transaccion su saldo es: " + mi_tarjeta.getSaldo(1111));
        }
        catch(java.lang.Exception error1) 
        {
            System.out.println("La contraseña es incorrecta");
        }
         
       
            
       
    }
}

