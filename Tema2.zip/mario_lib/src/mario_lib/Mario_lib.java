/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mario_lib;

import bpc.daw.mario.*;
public class Mario_lib {

    
    public static void main(String[] args) {
        Mario m = null;
        Luigi l = null;
        Seta s = null;
        
        Mario mario1 = new Mario(180);
        mario1.andarHacia(1920,1080);
     
        
        
    }
    
}
