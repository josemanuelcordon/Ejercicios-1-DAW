
package mario_lib;
import bpc.daw.objetos.*;

public class Ejercicio9 {

    
    public static void main(String args[]) 
    {
       Caja caja1 = new Caja("Bienvenidos al instituto");
       String mensaje_cerrada = caja1.getMensaje();
       System.out.println(mensaje_cerrada);
       caja1.abrirCaja();
       String mensaje_abierta = caja1.getMensaje();
       System.out.println(mensaje_abierta);
       
    }
}
