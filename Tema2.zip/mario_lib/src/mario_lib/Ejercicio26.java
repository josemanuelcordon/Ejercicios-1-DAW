
package mario_lib;
import java.lang.Thread;
import java.util.Scanner;

public class Ejercicio26 {

    
    public static void main(String args[]) 
    {
        try 
        {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Cuanto tiempo quieres esperar (segundos):");
        long tiempo_espera = lectura.nextLong() * 1000;
        Thread esperar = new Thread();
        esperar.sleep(tiempo_espera);
        System.out.println("Programa finalizado");
        }
        catch(java.lang.InterruptedException error1)
        {
            System.out.println("No se puede detener");
        }
    }
}
