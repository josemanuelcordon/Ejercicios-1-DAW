
package mario_lib;
import java.util.Scanner;

public class Ejercicio18 {

    
    public static void main(String args[]) 
    {
        Scanner lectura = new Scanner(System.in);
        String correo = lectura.nextLine();
        if ((correo.endsWith(".es")) || (correo.endsWith(".com")))
        {
        int posicion_arroba = correo.indexOf("@");
        String nombre = correo.substring(0,posicion_arroba);
        String dominio = correo.substring(posicion_arroba + 1);
        System.out.println("Su nombre es: " +nombre);
        System.out.println("Su dominio es: " +dominio);
        }
        else 
        {
            System.out.println("Introudzca un correo valido");
        }
    }
}
