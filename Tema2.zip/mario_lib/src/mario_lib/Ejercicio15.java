
package mario_lib;
import java.util.Scanner;

public class Ejercicio15 {

    
    public static void main(String args[]) 
    {
        String clave = "password";
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca una clave:");
        String cadena_introducida = lectura.nextLine();
        System.out.println(cadena_introducida.equals(clave));
      
    }
}
