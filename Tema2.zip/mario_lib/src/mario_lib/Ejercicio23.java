
package mario_lib;
import bpc.daw.objetos.TarjetaCredito;

public class Ejercicio23 {

   
    public static void main(String args[]) 
    {  
        try 
        {
            TarjetaCredito mi_tarjeta = new TarjetaCredito(1000,2222);
            mi_tarjeta.ingresarDinero(100);
            System.out.println("El saldo de la cuenta despues del ingreso de 100€ es: " + mi_tarjeta.getSaldo(2222));
            if(mi_tarjeta.sacarDinero(2000, 2222))
            {
                System.out.println("El saldo despues de retirar 2000€ es: " + mi_tarjeta.getSaldo(2222));         
            }
            else 
            {
                System.out.println("No hay saldo suficiente para sacar 2000€");
            }
           
        }
        catch(java.lang.Exception error1)
        {
            System.out.println("La contraseña es incorrecta");
        }
    }
}
