
package mario_lib;
import bpc.daw.mario.*;
import java.util.Scanner;
public class Ejercicio6 {

   
    public static void main(String args[]) 
    {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Elija la coordenada X de Mario (entero):");
        int coordenada_X_mario1 = lectura.nextInt();
        System.out.println("Elija la coordenada Y de Mario (entero):");
        int coordenada_Y_mario1 = lectura.nextInt();
        Mario mario1 = new Mario(coordenada_X_mario1, coordenada_Y_mario1);
    }
}
