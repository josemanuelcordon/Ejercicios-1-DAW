
package mario_lib;
import bpc.daw.objetos.*;

public class Ejercicio7 {

    
    public static void main(String args[]) 
    {
        DepositoAgua deposito1 = new DepositoAgua(15,50);
        deposito1.dibujar();
        int capacidad = deposito1.getCapacidadMaxima();
        int cantidad = deposito1.getCantidadActual();
        float tanto_por_uno =  (float)cantidad/capacidad;
        int porcentaje = (int)(tanto_por_uno * 100);
        System.out.println("El porcentaje de ocupacion del depósito es: " +porcentaje + "%");
    }
}
