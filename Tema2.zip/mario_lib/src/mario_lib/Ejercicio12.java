
package mario_lib;

import bpc.daw.objetos.*;
public class Ejercicio12 {


    public static void main(String args[]) 
    {
        MarcadorBaloncesto partidoGranada = new MarcadorBaloncesto("Estudiantes","CB Granada");
        partidoGranada.anotarCanasta('L',2);
        partidoGranada.anotarCanasta('V',3);
        partidoGranada.anotarCanasta('L',2);
        partidoGranada.anotarCanasta('V',2);
        partidoGranada.anotarCanasta('V',3);
        partidoGranada.anotarCanasta('L',1);
        partidoGranada.anotarCanasta('L',1);
        partidoGranada.anotarCanasta('V',2);
        String equipo1 = partidoGranada.getNombreLocal();
        String equipo2 = partidoGranada.getNombreVisitante();
        System.out.println("El equipo Local es: " + equipo1);
        System.out.println("El equipo Visitante es: " + equipo2);
        int puntosLocal = partidoGranada.getPuntosLocal();
        int puntosVisitante = partidoGranada.getPuntosVisitante();
        System.out.println("El " + equipo1 + "tiene: " + puntosLocal + " puntos.");
        System.out.println("El " + equipo2 + "tiene: " + puntosVisitante + " puntos.");
        String ganador = partidoGranada.getNombreEquipoGanador();
        String perdedor = partidoGranada.getNombreEquipoPerdedor();
        System.out.println("El equipo que va ganando es " + ganador);
        System.out.println("El equipo que va perdiedno es " + perdedor);
    }
}
