
package mario_lib;

import bpc.daw.objetos.*;
public class Ejercicio10 {

    public static void main(String args[]) {
       Caja caja1 = new Caja("Adónde vas, Bitter Kas");
       caja1.abrirCaja();
       String mensaje1 = caja1.getMensaje();
       System.out.println(mensaje1);
       caja1.cambiarMensaje("Ni una más, santo Tomás");
       String mensaje2 = caja1.getMensaje();
       System.out.println(mensaje2);
    }
}
