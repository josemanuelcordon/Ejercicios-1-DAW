
package mario_lib;
import java.net.InetAddress;
import java.util.Scanner;

public class Ejercicio28 {

    
    public static void main(String args[])
    {   
        try
        {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduzca un nombre de equipo:");
        String nombre_equipo = lectura.nextLine();
        InetAddress equipo = InetAddress.getByName(nombre_equipo);
        System.out.println("La direccion IP de " + nombre_equipo + " es: " + equipo.getHostAddress());
        }
        catch(java.net.UnknownHostException error1)
        {
            System.out.println("No existe ese nombre de equipo");
        }
    }
}