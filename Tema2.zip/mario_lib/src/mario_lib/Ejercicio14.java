package mario_lib;
import java.util.Scanner;

public class Ejercicio14 {

    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        System.out.println("Introduce una frase: ");
        String frase = lectura.nextLine();
        int longitud = frase.length();
        int mitad;
        if (longitud%2 == 0)
        {
            mitad = longitud/2 -1;
        }
        else 
        {
            mitad = longitud/2;
        }
        System.out.println(frase.charAt(mitad));
    }
}
