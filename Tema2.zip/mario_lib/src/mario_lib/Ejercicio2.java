
package mario_lib;
import bpc.daw.mario.*;
public class Ejercicio2 {
    
    public static void main(String args[]) 
    {
        Mario mario1 = new Mario(0,180);
        Mario mario2 = new Mario(640,320);
        Seta seta1 = new Seta(0,0);
        Cañon cañon1 = new Cañon(100,320);
        Planta planta1 = new Planta(400,500);
        Planta planta2 = new Planta(450,500);
        Planta planta3 = new Planta(500,500);
        Luigi luigi1 = new Luigi(250,0);
        Mario mario3 = new Mario(200,0);
    }
    
}
