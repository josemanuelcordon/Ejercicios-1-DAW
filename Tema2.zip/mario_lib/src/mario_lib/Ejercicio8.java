
package mario_lib;
import bpc.daw.objetos.*;

public class Ejercicio8 {

    
    public static void main(String args[]) 
    {
        DepositoAgua deposito1 = new DepositoAgua(15,20);
        DepositoAgua deposito2 = new DepositoAgua(5,20);
        System.out.println("ANTES");
        System.out.println("Deposito 1");
        deposito1.dibujar();
        System.out.println("Deposito 2");
        deposito2.dibujar();
        for(int i = 0; i < 5; i++)
        {
            deposito1.retirarLitro();
            deposito2.añadirLitro();
        }
        System.out.println("DESPUES");
        System.out.println("Deposito 1");
        deposito1.dibujar();
        System.out.println("Deposito 2");
        deposito2.dibujar();
    }
}
