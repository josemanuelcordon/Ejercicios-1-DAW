
package mario_lib;
import bpc.daw.mario.*;

public class Ejercicio3 {

    
    public static void main(String args[]) {
        Mario mario1 = new Mario(960,540);
        Luigi luigi1 = new Luigi(500,400);
        Seta seta1 = new Seta(1600,700);
        Planta planta1 = new Planta(960,0);
        Planta planta2 = new Planta(1000,0);
        Planta planta3 = new Planta(1040,0);
        Cañon cañon1 = new Cañon(0,540);
        
        seta1.andarHacia(0,0);
        mario1.saltar();
        cañon1.disparar(500,400);
        planta1.comer(true);
        planta2.comer(true);
        planta3.comer(true);
        
    }
}
