/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package daw.persona;
import java.time.*;
import java.io.*;

public class MarcadorBaloncesto {
    private String nombreLocal;
    private String nombreVisitante;
    private int puntosLocal;
    private int puntosVisitante;
    private LocalDate fecha;
     
    public MarcadorBaloncesto(String nL, String nV) {
        this.nombreLocal = nL;
        this.nombreVisitante = nV;
        this.puntosLocal = 0;
        this.puntosVisitante = 0;
        LocalDate fecha_actual = LocalDate.now();
        this.fecha = fecha_actual;
    }
    
    public MarcadorBaloncesto(String nL, String nV, LocalDate f) {
        this.nombreLocal = nL;
        this.nombreVisitante = nV;
        this.puntosLocal = 0;
        this.puntosVisitante = 0;
        this.fecha = f;
    }
    
    public MarcadorBaloncesto(String nL, int pL, String nV, int pV, LocalDate fecha) {
        this.nombreLocal = nL;
        this.nombreVisitante = nV;
        this.puntosLocal = pL;
        this.puntosVisitante = pV;
        this.fecha = fecha;
    }
    
    public void mostrarPartido() {
        System.out.println("Local: " +this.nombreLocal);
        System.out.println("Visitante: " +this.nombreVisitante);
        System.out.println("Puntos Local: " +this.puntosLocal);
        System.out.println("Puntos Visitante: " +this.puntosVisitante);
        System.out.println("Fecha: " +(this.fecha).getDayOfMonth() + " / " + (this.fecha).getMonthValue() + " / " + (this.fecha).getYear());
    }
    
    public void añadirCanasta(char equipo, int puntos) {
        equipo = Character.toLowerCase(equipo);
        if (equipo == 'v' || equipo == 'l' ) {
            if (puntos > 3 || puntos < 1) {
                System.out.println("La puntuación no es correcta");
            } else {
                if (equipo == 'v') {
                    this.puntosVisitante = this.puntosVisitante + puntos;
                } else {
                    this.puntosLocal = this.puntosLocal + puntos;
                }
            }
        } else {
            IllegalArgumentException ex = new IllegalArgumentException("Equipo no válido");
            throw ex;
            }
        
        }
        
    
    public void reset() {
        this.puntosLocal = 0;
        this.puntosVisitante = 0;
    }
    
    public int getPuntosLocal() {
        return this.puntosLocal;
    }
    
    public int getPuntosVisitante() {
        return this.puntosVisitante;
    }
    
    public boolean ganaLocal() {
        return (this.puntosLocal > this.puntosVisitante);
    }
    
    public boolean ganaVisitante() {
        return (this.puntosLocal < this.puntosVisitante);
    }
    
    public boolean hayEmpate() {
        return (this.puntosLocal == this.puntosVisitante);
    }
    
    public void guardar(String ruta) throws IOException {
        PrintWriter p = new PrintWriter(ruta);
        p.println("Equipo Visitante: " + nombreVisitante);
        p.println("Puntos Visitante: " + puntosVisitante);
        p.println("Equipo Local: " + nombreLocal);
        p.println("Puntos Local: " + puntosLocal);
        p.close();
        
    }
    
  
}
