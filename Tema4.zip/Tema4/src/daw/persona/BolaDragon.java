/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daw.persona;

/**
 *
 * @author jose
 */
public class BolaDragon {
    private static final int maximo_bolas;
    private static int siguienteBola;
    private int numero;
    
    static {
        maximo_bolas = 7;
        siguienteBola = 1;
    }
    
    private BolaDragon(int numero) {
        this.numero = numero;
        siguienteBola++;
    }
    
    
    
    
    
        
    public int getNumero() {
        return numero;       
    }
    
    public static BolaDragon crearBolaDragon() throws Exception {
        BolaDragon bola;
        if (siguienteBola < maximo_bolas ) {
            bola = new BolaDragon(siguienteBola);
            
        } else {
            if (siguienteBola == maximo_bolas) {
                System.out.println("Has invocado a Shen-Long"); 
                bola = new BolaDragon(siguienteBola);
                
                
            } else {
            Exception ex = new Exception("No se pueden crear más bolas");
            throw ex;
            }
        }
        return bola;
        
    }
    
    
    
}

