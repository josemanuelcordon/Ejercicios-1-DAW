
package daw.persona;


public class EquipoMusica {
    private Altavoz[] altavoces;
    
    public EquipoMusica(int numeroAltavoces) {
        altavoces = new Altavoz[numeroAltavoces];
        for(int i = 0; i < numeroAltavoces; i++) {
            altavoces[i] = new Altavoz();
        }
    }
    
    public Altavoz getAltavoz(int posicion) {
        return (altavoces[posicion-1]);
    }
    
    public void setVolumen(int numeroAltavoz, int volumen) {
        altavoces[numeroAltavoz - 1].setVolumen(volumen);
    }
}
