/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package daw.persona;
import java.util.Scanner;
import java.time.*;
import java.awt.*;
import java.io.*;
import daw.persona.BolaDragon.*;
import static daw.persona.BolaDragon.*;

public class Pruebas {

    
    public static void main(String args[]) {
        Scanner lectura = new Scanner(System.in);
        
    /*  System.out.println("Introduzca su DNI:");
        String dni = lectura.nextLine();
        DNI nuevo_dni = new DNI( dni); 
        System.out.println(nuevo_dni.letra);
        System.out.println(nuevo_dni.numero); 
    //  Prueba clase DNI
    
        Caja caja1 = new Caja("Hola soy la 1");
        Caja caja2 = new Caja(true, "Hola soy la 2");
        Caja caja3 = new Caja();
        
  /*    caja1.mostrarMensaje();
        caja2.mostrarMensaje();
        caja1.abrirCaja();
        caja1.mostrarMensaje();
        caja3.mostrarMensaje();
        caja3.abrirCaja();
        caja3.mostrarMensaje(); 
        caja2.setMensaje("Hola que tal");
        caja2.pasarMayusculas();
        caja2.mostrarMensaje(); 
    //  Prueba Clase Caja
        
      System.out.println("Introduzca día:");
        int diaMes = lectura.nextInt();
        System.out.println("Introduzca mes:");
        int mes = lectura.nextInt();
        System.out.println("Introduzca año:");
        int año = lectura.nextInt();
        
        LocalDate fecha = LocalDate.of(año, mes, diaMes);
        
        MarcadorBaloncesto partido1 = new MarcadorBaloncesto("Unicaja", "Real Madrid");
        MarcadorBaloncesto partido2 = new MarcadorBaloncesto("Unicaja", "Real Madrid", fecha);
        MarcadorBaloncesto partido3 = new MarcadorBaloncesto("Barcelona", 67, "Granada", 57, fecha);
        partido1.mostrarPartido();
        partido2.mostrarPartido();
        partido3.mostrarPartido(); 
    //  Prueba Clase MarcadorBaloncesto
    
    
      DNI dni = new DNI("25354655F");
        LocalDate fechaNacimiento = LocalDate.of(2001,4,14);
        Persona persona1 = new Persona("Jose Manuel Cordón Castillo", dni, 1200, fechaNacimiento);
        Persona persona2 = new Persona("Jose Manuel Cordón Castillo", 25354655, 'F',  1200, fechaNacimiento);
        Persona persona3 = new Persona("Jose Manuel Cordón Castillo", dni);
        Persona persona4 = new Persona("Jose Manuel Cordón Castillo", 25354655, 'F');
        
        persona1.getPersona();
        persona2.getPersona();
        persona3.getPersona();
        persona4.getPersona(); 
    //  Prueba Clase Persona 
    
    /*    Oficina oficina1 = new Oficina("Calamardo");
        Oficina oficina2 = new Oficina("Bob Esponja", 1);
        Oficina oficina3 = new Oficina("Bob Esponja", 0);
        Oficina oficina4 = new Oficina("Bob Esponja", 2);
        Oficina oficina5 = new Oficina("Manueh", 3);
        Oficina oficina6 = new Oficina("Carglass", 4); 
        
        Oficina lista[] = {oficina1, oficina2, oficina3, oficina4, oficina5, oficina6};
        for (int i = 0; i < lista.length; i++) {
            lista[i].mostrarOficina();
        } 
    //  Prueba Clase Oficina
        
    //  Punto punto1 = new Punto(400,500);
    //  Prueba Clase Punto
    
        persona1.getPersona();
        persona1.CobrarSueldo();
        persona1.CobrarSueldo();
        persona1.getPersona();
        
        
  /*    try {
            partido2.guardar("/home/jose/Escritorio/Holar");
        } catch (IOException e) {
            System.out.println("Error");
        } */

  /*      try {
          BolaDragon bola1 = crearBolaDragon();
          BolaDragon bola2 = crearBolaDragon();
          crearBolaDragon();
          crearBolaDragon();
          BolaDragon bola5 = crearBolaDragon();
          crearBolaDragon();
          System.out.println(bola5.getNumero());
          
        } catch (Exception e) {
            System.out.println(e);
        } */
        
        Altavoz altavoz1 = new Altavoz();
        altavoz1.setVolumen(180);
        System.out.println(altavoz1.getVolumen());
        System.out.println(altavoz1.toString());
        
  
    }
}