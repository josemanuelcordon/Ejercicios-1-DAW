/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daw.persona;

import java.util.*;

/**
 *
 * @author usuario
 */
public class Notas {
    private List<Double> notas;
    
    public Notas() {
        notas = new ArrayList<Double>();
    }
    
    public void añadirNota(double n) {
        notas.add(n);
    }
    
    public int getTotalNotas() {
        return (notas.size());
    }
    
    public OptionalDouble calcularNotaMedia() {
        double total_notas = 0;
        OptionalDouble contenedor;
        for (int i = 0; i< notas.size(); i++) {
            total_notas += notas.get(i);
        }
        double nota_media = total_notas/(notas.size());
        if(nota_media == 0) {
            contenedor = OptionalDouble.empty();
        } else {
            contenedor = OptionalDouble.of(nota_media);
        }
        return contenedor;
    }
    
    public OptionalDouble calcularNotaMaxima() {
        double nota_maxima = 0;
        for(int i = 0; i < notas.size(); i++) {
            if (notas.get(i) > nota_maxima) {
                nota_maxima = notas.get(i);
            }
        }
        return (OptionalDouble.of(nota_maxima));
    }
    
    
}
