/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daw.persona;
import java.util.Optional;
import java.util.Optional;

public class CajaMejorada {
    private String mensaje;
    private boolean abierta;
    
    public CajaMejorada(String m) {
        Optional contenedor = Optional.of(m);
        if (contenedor.isEmpty()) {
            IllegalArgumentException ex = new IllegalArgumentException("Parametro null no permitido");
            throw ex;
        } else {
            this.mensaje = m;
            this.abierta = false;
        }
        
    }
    
    public boolean abrir() {
        abierta = true;
        return abierta;
    }
    
    public boolean cerrar() {
        abierta = false;
        return abierta;
    }
    
    public Optional<String> getMensaje() {
        Optional<String> contenedor = Optional.of(mensaje);
        if (!abierta) {
            contenedor = Optional.empty();
        } 
        return contenedor;
    }
}
