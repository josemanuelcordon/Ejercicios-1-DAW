
package daw.persona;
import java.awt.*;

public class Punto {
    public int x;
    public int y;
    
    public Punto() {
        this.x = 0;
        this.y = 0;
    }
    
    public Punto(int x, int y) {
        Toolkit herramienta = Toolkit.getDefaultToolkit();
        Dimension dimension = herramienta.getScreenSize();
        int ancho = (int) dimension.getWidth();
        int altura = (int) dimension.getHeight();
        if (x < 0 || y < 0 || x>ancho || y>altura) {
            System.out.println("Introduce unas coordenadas válidas");
        } else {
            this.x = x;
            this.y = y;
        }
        
    }
    
    public Punto(Punto p) {
        this.x = (p.x) / 2;
        this.y = (p.y) / 2;
    }
    
    public Punto(double angulo, double distancia) {
        double radianes = Math.toRadians(angulo);
        this.x = (int) (Math.cos(radianes) * distancia);
        this.y = (int) (Math.sin(radianes) * distancia);
    }
    
    
    
   
}
