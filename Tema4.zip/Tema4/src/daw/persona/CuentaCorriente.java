
package daw.persona;

public class CuentaCorriente {
    public int numero;
    public double saldo;
    
    public CuentaCorriente() {
        this.numero = (int)(Math.random()*1001);
        this.saldo = 0;
    }
    
    public CuentaCorriente(int numero) {
        this.numero = numero;
        this.saldo = 0;
    }
    
    public CuentaCorriente(int numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }
    
    public void añadirDinero(double cantidad) {
       if (cantidad <= 0) {
            System.out.println("Introduzca una cantidad válida");
        }
        else {
            this.saldo = this.saldo + cantidad;
        }
    }
    
    public void retirarDinero(double cantidad) throws Exception {
        if ((cantidad < this.saldo) && (cantidad > 0)) {
            this.saldo = this.saldo - cantidad;
        } 
        else {
            if (cantidad > this.saldo) {
                Exception e = new Exception("No tiene tanto dinero");
                throw e;
            }
            else {
                Exception e = new Exception("No es una cantidad válida, tiene que ser mayor que 0");
                throw e;
            }
            
        }
    }
    
    public int getNumero() {
        return this.numero;
    }
    
    public double getSaldo() {
        return this.saldo;
    }
    
    
    
    
}
