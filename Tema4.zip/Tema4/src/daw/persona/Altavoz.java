
package daw.persona;
/** 
 * 
 * @author Jose Manuel Cordón Castillo
 * @version 1/02/2023
 */

public class Altavoz {
    //Campos de la clase
    public static final int VOL_MAX;
    public static final int VOL_MIN;
    private int volumen;
    static {
        VOL_MAX = 255;
        VOL_MIN = 0;
    }
    /**
     * Constructor para un altavoz con volumen 0
     */
    
    public Altavoz() {
        this.volumen = 0;
    } //Cierre del constructor
    /**
     * Método que establece el volumen del altavoz al volumen máximo permitidio
     */
    public void ponerVolumenMaximo() {
        this.volumen = VOL_MAX;
    } //Cierre del método.
    /**
     * Método para establecer el volumen del objeto altavoz
     * @param v El parámetro v es el volumen que le pondremos a nuestro altavoz
     */
    
    public void setVolumen(int v) {
        if((v > VOL_MAX) || (v < VOL_MIN)) {
            System.out.println("Volumen no admitido");
        } else {
            this.volumen = v;
        }
    } //Cierre del método.
    
    /**
     * Método que devuelve el volumen del altavoz.
     * @return El volumen de nuestro altavoz.
     */
    
    public int getVolumen() {
        return volumen;
    } //Cierre del método.
    
    /**
     * Método que devuelve un string y una barra que simboliza 
     * el porcentaje de volumen que tiene nuestro altavoz en ese momento.
     * @return Un String con el volumen actual y la barra de volumen actual.
     */
    
    public String toString() {
        String barra_asteriscos = "";
        long tanto_por_10 = Math.round((double)volumen/VOL_MAX * 10);
        for(int i = 1; i<= tanto_por_10; i++) {
            barra_asteriscos = barra_asteriscos + "*";
        }
        while (barra_asteriscos.length() < 10) {
            barra_asteriscos = barra_asteriscos + "-";
        }
        barra_asteriscos = "[" + volumen + "] " +barra_asteriscos;
        return barra_asteriscos;
    } //Cierre del método.
}//Cierre de la clase.
