
package daw.persona;


public class DNIMejorado {
    private int numero;
    private char letra;
    
    public DNIMejorado(int n) {
        this.numero = n;
        this.letra = calcularLetra(n);
    }
    
    public int getNumero() {
        return this.numero;
    }
    
    public char getLetra() {
        return this.letra;
    }
    
    private char calcularLetra(int n) {
        char[] letras_DNI = {'T','R','W','A','G','M','Y','F','P','D',
            'X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
        int resto = n%23;
        return (letras_DNI[resto]);
    }
}
