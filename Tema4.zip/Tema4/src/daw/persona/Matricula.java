
package daw.persona;


public class Matricula {
    private static int siguienteNúmeroMatrícula;
    private int numeroMatricula;
    private String nombreAlumno;
    private String nombreAsignatura;
    static {
        siguienteNúmeroMatrícula = 1;
    }
    
    public Matricula(String nombreAlumno, String nombreAsignatura) {
        this.nombreAlumno = nombreAlumno;
        this.nombreAsignatura = nombreAsignatura;
        this.numeroMatricula = siguienteNúmeroMatrícula;
        siguienteNúmeroMatrícula++;
    }
    
    public String getNombreAlumno() {
        return nombreAlumno;
    }
    
    public String getNombreAsignatura() {
        return nombreAsignatura;
    }
    
    public int getNúmeroMatrícula() {
        return numeroMatricula;
    }
    
    
    
}
