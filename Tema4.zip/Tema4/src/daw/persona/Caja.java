
package daw.persona;
/**
 * 
 * @author Jose Manuel Cordón Castillo
 * @version 2/02/2023
 */

public class Caja {
    //Campos de la clase
    private boolean abierto;
    private String mensaje;
    /**
     * Constructor para crear un objeto caja que este cerradp con el mensaje viva el tema 4
     */
    
    public Caja() {
        this.abierto = false;
        this.mensaje = "Viva el tema 4";
    }
    /**
     *  Método que crea una caja cerrada con el mensaje introducido
     * @param m El parámetro m es el mensaje que le introducimos a la caja
     */
    public Caja(String m) {
        this.abierto = false;
        this.mensaje = m;
    }
    /**
     * Crea una caja abierta o cerrada, con el mensaje que introduzca el usuario
     * @param a Booleano que indica si la caja esta cerrada(false) o abierta(true)
     * @param m Mensaje que se introduce en la caja
     */
    public Caja(boolean a, String m) {
        this.abierto = a;
        this.mensaje = m;
    }
    /**
     * Imprime true si la caja esta abierta o false si la caja esta cerrada
     */
    public void estaAbierta() {
        System.out.println(this.abierto);
    }
    /**
     * Si está abierta, imprime el mensaje, si esta cerrada, imprime que la caja esta cerrada
     */
    public void mostrarMensaje() {
        if (this.abierto) {
            System.out.println(this.mensaje);
        }
        else {
            System.out.println("La caja está cerrada");
        }
    }
    /**
     * Abre la caja (cambia el booleano a true)
     */
    public void abrir() {
        this.abierto = true;
    }
    /**
     * Cierra la caja (cambia el booleano a false)
     */
    
    public void cerrar() {
        this.abierto = false;
    }
    /** 
     * Cambia el mensaje de la caja por el introducido como parámetro
     * @param m Mensaje que queremos introducir en nuestra caja
     */
    public void setMensaje(String m) {
        this.mensaje = m;
    }
    /**
     * Pasa todas las letras del mensaje a mayúsculas
     */
    public void pasarMayusculas() {
        this.mensaje = (this.mensaje).toUpperCase();
    }
    /** 
     * Nos devuelve el mensaje de la caja
     * @return Devuelve el mensaje que tuviera la caja
     */
    public String getMensaje() {
        return this.mensaje;
    }
}
