
package daw.persona;

/**
 *
 * @author usuario
 */
public class Bola {
    private int numero; 
    
    public Bola(int numero) {
        this.numero = numero;
    }
    
    public int getNumero() {
        return this.numero;
    }
}
