/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package daw.persona;
import java.time.*;

class Persona {
    private String nombre;
    private DNI dni;
    private double sueldo = 0;
    private LocalDate fechaNacimiento;
    private CuentaCorriente cuenta = new CuentaCorriente();
    
    public Persona() {
        
    }
    
    public Persona(String n, DNI d, double s, LocalDate fN) {
        this.nombre = n;
        this.dni = d;
        this.sueldo = s;
        this.fechaNacimiento = fN;
        
    }
    
    public Persona(String n, int numDNI, char letraDNI, double s, LocalDate fN) {
        this.nombre = n;
        this.dni = new DNI(numDNI, letraDNI);
        this.sueldo = sueldo;
        this.fechaNacimiento = fN;
        this.cuenta = new CuentaCorriente();
        
    }
    
    public Persona(String n, DNI d) {
        this.nombre = n;
        this.dni = d;
        this.sueldo = 900;
        LocalDate fecha_actual = LocalDate.now();
        LocalDate fecha_20 = fecha_actual.minusYears(20);
        this.fechaNacimiento = fecha_20;

    }
    
    public Persona(String n, int numDNI, char letraDNI) {
        this.nombre = n;
        this.dni = new DNI(numDNI, letraDNI);
        this.sueldo = 900;
        LocalDate fecha_actual = LocalDate.now();
        LocalDate fecha_20 = fecha_actual.minusYears(20);
        this.fechaNacimiento = fecha_20;
        
    }
    
    public void getPersona() {
        System.out.println("Nombre: " + this.nombre);
        System.out.println("DNI: " + (this.dni).mostrarDNI());
        System.out.println("Sueldo: " + this.sueldo);
        System.out.println("Fecha de nacimiento: " + this.fechaNacimiento);
        System.out.println("Cuenta Corriente: Número(" + (this.cuenta).getNumero() + ") Saldo (" + (this.cuenta).getSaldo() + ")");
    }
    
    public void aumentarsueldo(int porcentaje) {
        this.sueldo = this.sueldo + (this.sueldo * (porcentaje / 100));
    }
    
    public void CobrarSueldo() {
        (this.cuenta).añadirDinero(sueldo);
    }
    
    public String getNombre() {
        return this.nombre;
    }
    
    public DNI getDNI() {
        return this.dni;
    }
    
    public double getSueldo() {
        return this.sueldo;
    }
    
    public LocalDate getFechaNacimiento() {
        return this.fechaNacimiento;
    }
    
    public CuentaCorriente getCuentaCorriente() {
        return this.cuenta;
    }
    
    public boolean esMayorEdad() {
        Period edad = Period.between(fechaNacimiento, LocalDate.now());
        return (edad.getYears()>=18);
    }
    
    public boolean tieneDinero() {
        return ((this.cuenta).getSaldo() >= 0);
    }
    
    public boolean esMileurista() {
        return ((this.sueldo) <= 1200);
    }
}
