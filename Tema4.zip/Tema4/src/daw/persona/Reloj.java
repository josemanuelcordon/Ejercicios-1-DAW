
package daw.persona;

import java.time.LocalTime;


public class Reloj {
    private LocalTime hora;
    
    public Reloj() {
        hora = LocalTime.now();
    }

    public void añadir(int segundos) {
        hora.minusSeconds(segundos);
    }
    
    public boolean esNoche() {
        boolean noche = false;
        int hora_dia = hora.getHour();
        if (hora_dia >= 20 || hora_dia <= 8) {
            noche = true;
        }
        return noche;
    }
    
    public void esperar(int segundos) {
        try {
        Thread.sleep(segundos * 1000);
        hora = LocalTime.now();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public String toString() {
        String hora_string = "";
        String puntos = ":";
        hora_string += hora.getHour() + puntos+ hora.getMinute() + puntos + hora.getSecond();
        return hora_string;
    }
}
