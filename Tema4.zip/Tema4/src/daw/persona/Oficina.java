
package daw.persona;
import java.util.ArrayList;
import java.time.*;

public class Oficina extends Persona {
    private String nombre;
    private ArrayList<Persona> trabajadores;
    
    
    private Oficina(String nombre) {
        this.nombre = nombre;
        this.trabajadores = new ArrayList<Persona>();
    }
    
    private Oficina(String nombre, int tipo) {
        this.nombre = nombre;
        this.trabajadores = new ArrayList<Persona>();
        if (tipo == 1) {
            this.trabajadores.add(new Persona("Antonio Pérez Pérez", new DNI("11111111H"), 900, LocalDate.of(2000, 2, 28) ));
        }
        if (tipo == 2) {
            this.trabajadores.add(new Persona("Antonio Pérez Pérez", new DNI("11111111H"), 900, LocalDate.of(2000, 2, 28) ));
            this.trabajadores.add(new Persona("Luis López  Lñopez", new DNI("22222222J"), 1000, LocalDate.of(1995, 9, 10) ));
        }
        if (tipo == 3) {
            this.trabajadores.add(new Persona("Antonio Pérez Pérez", new DNI("11111111H"), 900, LocalDate.of(2000, 2, 28) ));
            this.trabajadores.add(new Persona("Luis López  Lñopez", new DNI("22222222J"), 1000, LocalDate.of(1995, 9, 10) ));
            this.trabajadores.add(new Persona("Ana Díaz Díaz", new DNI("33333333P"), 1200 , LocalDate.of(1985, 5, 21) ));
        } else {
            IllegalArgumentException ex = new IllegalArgumentException("Tipo no válido, introduzca un tipo entre 0 y 3");
            throw ex;
        }
    }
        
    private Oficina() {
        new Oficina("Industrias DAW", 3);
    }
     
    
    
    public void añadirEmpleado(Persona p) {
        trabajadores.add(p);
    }
    
    public void añadirEmpleado(String nombre, String DNI, double sueldo, LocalDate fechaNac) {
        DNI dni_empleado = new DNI(DNI);
        Persona nuevoEmpleado = new Persona(nombre,dni_empleado, sueldo, fechaNac);
        trabajadores.add(nuevoEmpleado);
    }
    
    public int getTotalEmpleados() {
        return trabajadores.size();
    }
    
    public int getTotalEmpleadosMileuristas() {
        int n_mileuristas = 0;
        for (int i = 0; i<trabajadores.size(); i++) {
            if ((trabajadores.get(i)).esMileurista()) {
                n_mileuristas++;
            }
        }
        return n_mileuristas;
    }
    
    public ArrayList<Persona> getMileuristas() {
        ArrayList mileuristas = new ArrayList<Persona>();
        for (int i = 0; i < trabajadores.size(); i++) {
            if ((trabajadores.get(i)).esMileurista()) {
                mileuristas.add(trabajadores.get(i));
            }
        }
        return mileuristas;
    }
    
    public boolean trabaja(Persona p) {
        return (trabajadores.contains(p));
    }
    
    public void pagarEmpleados() {
        for (int i = 0; i < trabajadores.size(); i++) {
            (trabajadores.get(i)).CobrarSueldo();
        }
    }
    
    public void mostrarInformeEmpleados() {
        System.out.println("La oficina se llama: " + this.nombre);
        System.out.println("INFORMACION EMPRESA");
        if (trabajadores.isEmpty()) {
            System.out.println("No hay trabajadores");
        } else {
            for(int i = 0; i<trabajadores.size(); i++) {
                System.out.println("Nombre: " + (trabajadores.get(i)).getNombre());
                System.out.println("Sueldo: " + (trabajadores.get(i)).getSueldo());
                if (trabajadores.get(i).esMileurista()) {
                    System.out.println("Es mileurista");
                } 
                else {
                    System.out.println("No es mileurista");
                }
            }
        }    
    }
    
    public double getSueldoMedio() throws Exception {
        double sueldo_todos = 0;
        int n_trabajadores = trabajadores.size();
        
        for (int i = 0; i < n_trabajadores; i++) {
            sueldo_todos = sueldo_todos + (trabajadores.get(i)).getSueldo();
        }
        double sueldo_medio = sueldo_todos/n_trabajadores;
        if (sueldo_medio > 0) {
            return sueldo_medio;
        }
        else {
            Exception e = new Exception("No hay empleados en la empresa");
            throw e;
        }
    }
    
    public static Oficina getOficinaVacia() {
        return (new Oficina("Oficina Vacia",0));
        
    }
    
    public static Oficina getOficinaPequeña() {
        return (new Oficina("Oficina Pequeña", 1));
    }
    
    public static Oficina getOficinaMediana() {
        return (new Oficina("Oficina Mediana", 2));
    }
    
    public static Oficina getOficinaGrande() {
        return (new Oficina("Oficina Grande", 3));
    }
        
}

