
package daw.persona;

public class DNI {
    public int numero;
    public char letra;
    
    public DNI() {
        
    }
    
    public DNI(int numero, char letra)  {
        this.numero = numero;
        this.letra = letra;
    }
    
    public DNI(String dni) {
       this.numero = (int)(Integer.parseInt(dni.substring(0,8)));
       this.letra = dni.charAt(8);
       
    }
    
    public String mostrarDNI() {
        return ("" + this.numero + this.letra);
    }
    
    
    
    
}
