/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daw.persona;

import java.util.*;

/**
 *
 * @author usuario
 */
public class Bombo {
    private Queue<Bola> bolas;
    
    
    public Bombo(int totalBolas) {
        bolas = new ArrayDeque(totalBolas);
        int aleatorio;
        for (int i = 0; i <totalBolas; i++) {
            aleatorio = (int)(Math.random()*100 + 1);
            bolas.add(new Bola(aleatorio));
        }
    }
    
    public int getNumeroBolas() {
        return (bolas.size());
    }
    
    public Optional<Bola> sacarBola() {
        Bola siguienteBola = bolas.poll();
        return (Optional.of(siguienteBola));
    }
    
    
}
