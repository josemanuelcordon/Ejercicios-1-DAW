
package daw.persona;
import java.util.ArrayList;

public class Fraccion {
    private int numerador;
    private int denominador;
    
    
    public Fraccion(int numerador, int denominador) {
        this.numerador = numerador;
        this.denominador = denominador;
    }
    
    public int getNumerador() {
        return numerador;
    }
    
    public int getDenominador() {
        return denominador;
    }
    
    public double getValorReal() {
        return (double)numerador/denominador;
    }
    
    public Fraccion getInversa() {
        return ( new Fraccion(this.denominador, this.numerador));
    }
    
    public static Fraccion sumar(Fraccion a, Fraccion b) {
        int num = (a.getNumerador() * b.getDenominador()) + (a.getDenominador() + b.getNumerador());
        int den = (a.getDenominador()) * (b.getDenominador());
        return ( new Fraccion( num, den));
                
    }
    
    public static Fraccion multiplicar(Fraccion a, Fraccion b) {
        int num = a.getNumerador() * b.getNumerador();
        int den = a.getDenominador() * b.getDenominador();
        return (new Fraccion(num, den));
    }
    
    public static Fraccion dividir(Fraccion a, Fraccion b) {
        Fraccion division = multiplicar(a,b.getInversa());
        return division;
    }
    
    
    
   
}
