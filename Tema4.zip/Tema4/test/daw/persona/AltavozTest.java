/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package daw.persona;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jose
 */
public class AltavozTest {
    
    public AltavozTest() {
    }

    @Test
    public void testPonerVolumenMaximo() {
    }

    @Test
    public void testSetVolumen() {
        Altavoz altavoz1 = new Altavoz();
        System.out.println("Volumen 1");
        altavoz1.setVolumen(255);
        System.out.println("Volumen 2");
        altavoz1.setVolumen(-4);
        System.out.println("Volumen 3");
        altavoz1.setVolumen(256);
        System.out.println("Volumen 4");
        altavoz1.setVolumen(0);
    }

    @Test
    public void testGetVolumen() {
        
    }

    @Test
    public void testToString() {
        Altavoz altavoz1 = new Altavoz();
        float porcentaje;
        for(int i=0; i<= 300; i++) {
            porcentaje = (i/(float)255) * 100;
            altavoz1.setVolumen(i);
            
            System.out.print(altavoz1.toString());
            System.out.println("   El porcentaje es: " +porcentaje + "%");
            
        }
    }
    
}
