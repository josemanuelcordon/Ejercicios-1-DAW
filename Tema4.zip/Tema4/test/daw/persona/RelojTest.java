/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package daw.persona;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class RelojTest {
    
    public RelojTest() {
    }

    @Test
    public void testAñadir() {
    }

    @Test
    public void testEsNoche() {
    }

    @Test
    public void testEsperar() {
    }

    @Test
    public void testToString() {
        Reloj reloj_actual = new Reloj();
        System.out.println("La hora es:  " + reloj_actual.toString());
        reloj_actual.esperar(200);
        System.out.println("La hora es:  " + reloj_actual.toString());
        
    }
    
}
