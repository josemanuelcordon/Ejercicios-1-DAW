/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package daw.persona;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author usuario
 */
public class BomboTest {
    
    public BomboTest() {
        
    }

    @Test
    public void testGetNumeroBolas() {
        Bombo bombo1 = new Bombo(6);
        System.out.println(bombo1.toString());
        assertEquals(bombo1.getNumeroBolas(),6);
    }

    @Test
    public void testSacarBola() {
        Bombo bombo1 = new Bombo(100);
        for (int i = 0; i<100; i++) {
            System.out.println("La bola sacada es: " + ((bombo1.sacarBola()).get()).getNumero());
        }
    }
    
}
