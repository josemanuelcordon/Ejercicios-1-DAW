
package daw.persona;

import org.junit.Test;
import static org.junit.Assert.*;

public class BolaDragonTest {
    
    public BolaDragonTest() {
    }

    @Test
    public void testGetNumero() throws Exception {
        BolaDragon boladragon;
        for(int i =1; i<= 7; i++) {
            boladragon = BolaDragon.crearBolaDragon();
            System.out.println(boladragon.getNumero() == i);
        }
    }

    @Test (expected = java.lang.Exception.class)
    public void testCrearBolaDragon() throws Exception {
        BolaDragon Bola1, Bola2, Bola3, Bola4, Bola5, Bola6, Bola7, Bola8;
        
        Bola1 = BolaDragon.crearBolaDragon();
        Bola2 = BolaDragon.crearBolaDragon();
        Bola3 = BolaDragon.crearBolaDragon();
        System.out.println(Bola1.toString());
        System.out.println(Bola2.hashCode());
        Bola4 = BolaDragon.crearBolaDragon();
        Bola5 = BolaDragon.crearBolaDragon();
        Bola6 = BolaDragon.crearBolaDragon();
        Bola7 = BolaDragon.crearBolaDragon();
        Bola8 = BolaDragon.crearBolaDragon();
    }
    
}
